import logging
import sqlite3
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (Updater, CommandHandler, CallbackQueryHandler,
                          MessageHandler, Filters, CallbackContext)
from config import TOKEN, OWNER_ID

logging.basicConfig(level=logging.INFO)
conn = sqlite3.connect("support.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    username TEXT,
    category TEXT,
    subcategory TEXT,
    message TEXT,
    status TEXT DEFAULT 'open'
)""")
cursor.execute("""CREATE TABLE IF NOT EXISTS moderators (
    user_id INTEGER PRIMARY KEY
)""")
conn.commit()

def is_moderator(user_id: int) -> bool:
    if user_id == OWNER_ID:
        return True
    cursor.execute("SELECT 1 FROM moderators WHERE user_id=?", (user_id,))
    return cursor.fetchone() is not None

def start(update: Update, context: CallbackContext):
    keyboard = [
        [InlineKeyboardButton("📌 Проблема", callback_data='problem')],
        [InlineKeyboardButton("💡 Предложение", callback_data='suggestion')]
    ]
    update.message.reply_text("Выберите тип обращения:", reply_markup=InlineKeyboardMarkup(keyboard))

def button_handler(update: Update, context: CallbackContext):
    query = update.callback_query
    query.answer()
    category = query.data

    if category == 'problem':
        subkeyboard = [
            [InlineKeyboardButton("🖥 Сервер", callback_data='sub:Сервер')],
            [InlineKeyboardButton("👤 Аккаунт", callback_data='sub:Аккаунт')],
            [InlineKeyboardButton("💰 Донат", callback_data='sub:Донат')],
            [InlineKeyboardButton("❓ Другое", callback_data='sub:Другое')]
        ]
        query.edit_message_text("Уточните проблему:", reply_markup=InlineKeyboardMarkup(subkeyboard))
        context.user_data['category'] = 'Проблема'
    elif category == 'suggestion':
        context.user_data['category'] = 'Предложение'
        context.user_data['subcategory'] = '—'
        query.edit_message_text("Опишите ваше предложение:")
        context.user_data['awaiting_text'] = True
    elif category.startswith('sub:'):
        sub = category.split(":")[1]
        context.user_data['subcategory'] = sub
        query.edit_message_text("Опишите суть проблемы:")
        context.user_data['awaiting_text'] = True

def handle_message(update: Update, context: CallbackContext):
    if context.user_data.get('awaiting_text'):
        category = context.user_data.get('category')
        subcategory = context.user_data.get('subcategory', '—')
        message = update.message.text
        user_id = update.message.from_user.id
        username = update.message.from_user.username or update.message.from_user.first_name

        cursor.execute("INSERT INTO tickets (user_id, username, category, subcategory, message) VALUES (?, ?, ?, ?, ?)",
                       (user_id, username, category, subcategory, message))
        conn.commit()

        update.message.reply_text("✅ Ваша заявка отправлена! Ожидайте ответа.")
        context.user_data.clear()

        context.bot.send_message(OWNER_ID,
            f"📬 Новая заявка

"
            f"ID тикета: {cursor.lastrowid}
"
            f"От: @{username} ({user_id})
"
            f"Категория: {category} / {subcategory}
"
            f"Сообщение: {message}")

def list_tickets(update: Update, context: CallbackContext):
    if not is_moderator(update.effective_user.id):
        return update.message.reply_text("⛔ Нет доступа")
    cursor.execute("SELECT id, username, category, subcategory, status FROM tickets WHERE status='open'")
    rows = cursor.fetchall()
    if not rows:
        return update.message.reply_text("Нет открытых заявок.")
    text = "\n".join([f"#{r[0]} от @{r[1]} — {r[2]}/{r[3]}" for r in rows])
    update.message.reply_text("📋 Открытые заявки:\n" + text)

def reply(update: Update, context: CallbackContext):
    if not is_moderator(update.effective_user.id):
        return update.message.reply_text("⛔ Нет доступа")
    if len(context.args) < 2:
        return update.message.reply_text("Использование: /reply <id> <ответ>")
    ticket_id = context.args[0]
    text = ' '.join(context.args[1:])
    cursor.execute("SELECT user_id FROM tickets WHERE id=?", (ticket_id,))
    row = cursor.fetchone()
    if not row:
        return update.message.reply_text("⛔ Тикет не найден.")
    context.bot.send_message(row[0], f"💬 Ответ по заявке #{ticket_id}:
{text}")
    cursor.execute("UPDATE tickets SET status='closed' WHERE id=?", (ticket_id,))
    conn.commit()
    update.message.reply_text("✅ Ответ отправлен.")

def addmod(update: Update, context: CallbackContext):
    if update.effective_user.id != OWNER_ID:
        return update.message.reply_text("⛔ Только владелец может управлять модераторами.")
    if not context.args:
        return update.message.reply_text("Использование: /addmod <user_id>")
    cursor.execute("INSERT OR IGNORE INTO moderators (user_id) VALUES (?)", (int(context.args[0]),))
    conn.commit()
    update.message.reply_text("✅ Модератор добавлен.")

def delmod(update: Update, context: CallbackContext):
    if update.effective_user.id != OWNER_ID:
        return update.message.reply_text("⛔ Только владелец может управлять модераторами.")
    if not context.args:
        return update.message.reply_text("Использование: /delmod <user_id>")
    cursor.execute("DELETE FROM moderators WHERE user_id=?", (int(context.args[0]),))
    conn.commit()
    update.message.reply_text("✅ Модератор удалён.")

def mods(update: Update, context: CallbackContext):
    if not is_moderator(update.effective_user.id):
        return update.message.reply_text("⛔ Нет доступа")
    cursor.execute("SELECT user_id FROM moderators")
    rows = cursor.fetchall()
    mod_list = [str(r[0]) for r in rows]
    update.message.reply_text("👥 Модераторы:
" + "\n".join(mod_list) if mod_list else "Нет модераторов.")

def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CallbackQueryHandler(button_handler))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))
    dp.add_handler(CommandHandler("list", list_tickets))
    dp.add_handler(CommandHandler("reply", reply))
    dp.add_handler(CommandHandler("addmod", addmod))
    dp.add_handler(CommandHandler("delmod", delmod))
    dp.add_handler(CommandHandler("mods", mods))

    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()
